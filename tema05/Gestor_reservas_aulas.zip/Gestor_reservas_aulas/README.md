#Gestor de Reservas de Aulas — MEDAC Fuenlabrada

Aplicación de consola en Java para gestionar las reservas de aulas del centro MEDAC Fuenlabrada. La aplicación se conecta a una base de datos PostgreSQL mediante JDBC, desplegada en un contenedor Docker con volumen persistente.


##Requisitos Previos

 Java JDK 17 o superior.
 Apache Maven 3.8+(o integrado en el IDE).
 Docker Engine & Docker Compose.
 IDE Java (NetBeans).


##Tecnologías Utilizadas

Lenguaje: Java 17
 Gestor de Dependencias: Apache Maven
Base de Datos: PostgreSQL 16
Contenedor: Docker & Docker Compose
Conectividad: JDBC 


##Estructura del Proyecto
compose.yaml: Configuración de PostgreSQL en Docker.
pom.xml: Dependencias del proyecto (incluye el driver JDBC de PostgreSQL).
src: Código fuente de la aplicación en Java.
  es.medac.Main.java: Clase principal con el menú interactivo.
  es.medac.config.DatabaseConfig.java: Configuración de la conexión a PostgreSQL.
README.md: Documentación del proyecto.
