/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.medac;

import es.medac.config.DatabaseConfig;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
int opcion = -1;

while (opcion != 0) {
System.out.println("\n=================================");
System.out.println("     GESTOR DE RESERVAS");
System.out.println("=================================");
System.out.println("1. Registrar una reserva");
System.out.println("2. Mostrar todas las reservas");
System.out.println("3. Buscar reservas por aula");
System.out.println("4. Eliminar una reserva");
System.out.println("0. Salir");
System.out.println("=================================");
System.out.print("Selecciona una opción: ");

opcion = Integer.parseInt(scanner.nextLine());

switch (opcion) {
case 1 -> {
    System.out.print("Nombre del alumno: ");
    String alumno = scanner.nextLine();
    System.out.print("Aula: ");
    String aula = scanner.nextLine();
    System.out.print("Fecha (YYYY-MM-DD): ");
    String fecha = scanner.nextLine();

    String sql = "INSERT INTO reserva (alumno, aula, fecha) VALUES (?, ?, ?)";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, alumno);
        pstmt.setString(2, aula);
        pstmt.setDate(3, Date.valueOf(fecha));

        pstmt.executeUpdate();
        System.out.println("Reserva registrada correctamente.");
    } catch (SQLException e) {
        System.out.println("Error al registrar: " + e.getMessage());
    }
}
case 2 -> {
    String sql = "SELECT * FROM reserva";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql);
         ResultSet rs = pstmt.executeQuery()) {

        boolean hayReservas = false;
        while (rs.next()) {
            hayReservas = true;
            System.out.println("ID: " + rs.getLong("id") + 
           " | Alumno: " + rs.getString("alumno") + 
           " | Aula: " + rs.getString("aula") + 
           " | Fecha: " + rs.getDate("fecha"));
        }
        if (!hayReservas) {
            System.out.println("No hay reservas registradas.");
        }
    } catch (SQLException e) {
        System.out.println("Error al consultar: " + e.getMessage());
    }
}
case 3 -> {
    System.out.print("Introduce el aula a buscar: ");
    String aulaBuscada = scanner.nextLine();

    String sql = "SELECT * FROM reserva WHERE aula = ?";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, aulaBuscada);
        ResultSet rs = pstmt.executeQuery();

        boolean hayReservas = false;
        while (rs.next()) {
            hayReservas = true;
            System.out.println("ID: " + rs.getLong("id") + 
           " | Alumno: " + rs.getString("alumno") + 
           " | Aula: " + rs.getString("aula") + 
           " | Fecha: " + rs.getDate("fecha"));
        }
        if (!hayReservas) {
            System.out.println("No existen reservas para el aula " + aulaBuscada);
        }
    } catch (SQLException e) {
        System.out.println("Error al buscar: " + e.getMessage());
    }
}
case 4 -> {
    System.out.print("Introduce el ID de la reserva a eliminar: ");
    long id = Long.parseLong(scanner.nextLine());

    String sql = "DELETE FROM reserva WHERE id = ?";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setLong(1, id);
        int filasAfectadas = pstmt.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Reserva eliminada correctamente.");
        } else {
            System.out.println("No se encontró ninguna reserva con ese ID.");
        }
    } catch (SQLException e) {
        System.out.println("Error al eliminar: " + e.getMessage());
    }
}
case 0 -> System.out.println("Saliendo del programa...");
default -> System.out.println("Opción no válida.");
}
}
scanner.close();
}
}

