/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package es.medac;

/**
 *
 * @author ADMIN
 */
public class Gestor_reservas_aulas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
