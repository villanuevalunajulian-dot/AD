package es.medac;

import es.medac.config.DatabaseConfig;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
int opcion = -1;

while (opcion != 0) {
    System.out.println("=================================");
    System.out.println(" GESTOR DE RESERVAS - MEDAC");
    System.out.println("=================================");
    System.out.println("1. Registrar una reserva");
    System.out.println("2. Mostrar todas las reservas");
    System.out.println("3. Buscar reservas por aula");
    System.out.println("4. Eliminar una reserva");
    System.out.println("5. Modificar una reserva");
    System.out.println("6. Buscar alumno por texto (LIKE)");
    System.out.println("7. Buscar por rango de fechas (BETWEEN)");
    System.out.println("8. Probar transaccion (SAVEPOINT)");
    System.out.println("0. Salir");
    System.out.println("=================================");
    System.out.print("Selecciona una opcion: ");

    try {
        opcion = Integer.parseInt(scanner.nextLine());
    } catch (Exception e) {
        System.out.println("Opcion no valida.");
        continue;
    }

    switch (opcion) {
        case 1 -> {
            System.out.print("Nombre del alumno: ");
            String alumno = scanner.nextLine();
            System.out.print("Aula: ");
            String aula = scanner.nextLine();
            System.out.print("Fecha (YYYY-MM-DD): ");
            String fecha = scanner.nextLine();

            String sql = "INSERT INTO reserva (alumno, aula, fecha) VALUES (?, ?, ?)";
            try (Connection conn = DatabaseConfig.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, alumno);
                pstmt.setString(2, aula);
                pstmt.setDate(3, Date.valueOf(fecha));

                pstmt.executeUpdate();
        System.out.println("Reserva registrada correctamente.");
    } catch (SQLException e) {
        System.out.println("Error al guardar: " + e.getMessage());
    }
}
case 2 -> {
    String sql = "SELECT * FROM reserva ORDER BY fecha ASC";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql);
         ResultSet rs = pstmt.executeQuery()) {

        boolean hay = false;
        while (rs.next()) {
            hay = true;
            System.out.println("ID: " + rs.getLong("id") +
                    " | Alumno: " + rs.getString("alumno") +
                    " | Aula: " + rs.getString("aula") +
                    " | Fecha: " + rs.getDate("fecha"));
        }
        if (!hay) {
            System.out.println("No hay reservas.");
        }
    } catch (SQLException e) {
        System.out.println("Error al consultar: " + e.getMessage());
    }
}
case 3 -> {
    System.out.print("Introduce el aula a buscar: ");
    String aula = scanner.nextLine();

    String sql = "SELECT * FROM reserva WHERE aula = ? ORDER BY fecha ASC";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, aula);
        ResultSet rs = pstmt.executeQuery();

        boolean hay = false;
        while (rs.next()) {
            hay = true;
            System.out.println("ID: " + rs.getLong("id") +
            " | Alumno: " + rs.getString("alumno") +
            " | Aula: " + rs.getString("aula") +
            " | Fecha: " + rs.getDate("fecha"));
}
        if (!hay) {
            System.out.println("No hay reservas en ese aula.");
        }
    } catch (SQLException e) {
        System.out.println("Error al buscar: " + e.getMessage());
    }
}
case 4 -> {
    System.out.print("Introduce el ID de la reserva a borrar: ");
    long id = Long.parseLong(scanner.nextLine());

    String sql = "DELETE FROM reserva WHERE id = ?";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setLong(1, id);
        int filas = pstmt.executeUpdate();

        if (filas > 0) {
            System.out.println("Reserva borrada.");
        } else {
            System.out.println("No existe ninguna reserva con ese ID.");
        }
    } catch (SQLException e) {
        System.out.println("Error al borrar: " + e.getMessage());
    }
}
case 5 -> {
    System.out.print("ID de la reserva a modificar: ");
    long id = Long.parseLong(scanner.nextLine());
    System.out.print("Nuevo alumno: ");
    String alumno = scanner.nextLine();
    System.out.print("Nueva aula: ");
    String aula = scanner.nextLine();
    System.out.print("Nueva fecha (YYYY-MM-DD): ");
    String fecha = scanner.nextLine();

    String sql = "UPDATE reserva SET alumno = ?, aula = ?, fecha = ? WHERE id = ?";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, alumno);
        pstmt.setString(2, aula);
        pstmt.setDate(3, Date.valueOf(fecha));
        pstmt.setLong(4, id);

        int filas = pstmt.executeUpdate();

        if (filas > 0) {
            System.out.println("Reserva modificada correctamente.");
        } else {
            System.out.println("No existe el ID introducido.");
        }
    } catch (SQLException e) {
        System.out.println("Error al modificar: " + e.getMessage());
    }
}
case 6 -> {
    System.out.print("Texto a buscar en el alumno: ");
    String texto = scanner.nextLine();

    String sql = "SELECT * FROM reserva WHERE alumno LIKE ?";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, "%" + texto + "%");
        ResultSet rs = pstmt.executeQuery();

        boolean hay = false;
        while (rs.next()) {
            hay = true;
            System.out.println("ID: " + rs.getLong("id") +
            " | Alumno: " + rs.getString("alumno") +
            " | Aula: " + rs.getString("aula") +
            " | Fecha: " + rs.getDate("fecha"));
        }
        if (!hay) {
            System.out.println("No hay coincidencias.");
        }
    } catch (SQLException e) {
        System.out.println("Error en la busqueda: " + e.getMessage());
    }
}
case 7 -> {
    System.out.print("Fecha inicio (YYYY-MM-DD): ");
    String f1 = scanner.nextLine();
    System.out.print("Fecha fin (YYYY-MM-DD): ");
    String f2 = scanner.nextLine();

    String sql = "SELECT * FROM reserva WHERE fecha BETWEEN ? AND ? ORDER BY fecha ASC";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setDate(1, Date.valueOf(f1));
        pstmt.setDate(2, Date.valueOf(f2));

        ResultSet rs = pstmt.executeQuery();

        boolean hay = false;
        while (rs.next()) {
            hay = true;
            System.out.println("ID: " + rs.getLong("id") +
                " | Alumno: " + rs.getString("alumno") +
                " | Aula: " + rs.getString("aula") +
                " | Fecha: " + rs.getDate("fecha"));
        }
        if (!hay) {
            System.out.println("No hay reservas entre esas fechas.");
        }
    } catch (SQLException e) {
        System.out.println("Error en el rango: " + e.getMessage());
    }
}
case 8 -> {
    System.out.print("ID de reserva para probar transaccion: ");
    long id = Long.parseLong(scanner.nextLine());

    Connection conn = null;
    try {
        conn = DatabaseConfig.getConnection();
        conn.setAutoCommit(false);

        //Cambiar fecha
        String sql1 = "UPDATE reserva SET fecha = '2026-12-31' WHERE id = ?";
        PreparedStatement ps1 = conn.prepareStatement(sql1);
        ps1.setLong(1, id);
        ps1.executeUpdate();
        ps1.close();
        System.out.println(" Fecha cambiada a 2026-12-31.");

        // Crear punto de guardado8
        Savepoint sp = conn.setSavepoint("Punto1");

        // Cambiar aula
        String sql2 = "UPDATE reserva SET aula = 'AULA-PRUEBA' WHERE id = ?";
        PreparedStatement ps2 = conn.prepareStatement(sql2);
        ps2.setLong(1, id);
        ps2.executeUpdate();
        ps2.close();
        System.out.println(" Aula cambiada a AULA-PRUEBA.");

        //Cancelar solo el cambio de aula
        conn.rollback(sp);
        System.out.println(" Rollback hasta Punto1.");

        //Guardar definitivamente
        conn.commit();
        System.out.println("Commit realizado.");

    } catch (SQLException e) {
        System.out.println("Error en transaccion: " + e.getMessage());
        if (conn != null) {
            try {
                conn.rollback();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    } finally {
        if (conn != null) {
            try {
                conn.setAutoCommit(true);
                conn.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
case 0 -> System.out.println("Saliendo...");
default -> System.out.println("Opción invalida.");
}
}
        scanner.close();
    }
}

